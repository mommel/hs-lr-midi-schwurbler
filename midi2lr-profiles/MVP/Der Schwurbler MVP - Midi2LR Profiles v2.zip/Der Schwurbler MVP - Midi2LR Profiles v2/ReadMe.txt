
==================
Der Schwurbler MVP
==================

Please Note: 
These Sample Profiles are for Lightroom 10 and Midi2LR Version 4 or later.


The MIDI2LR application uses profiles to map MIDI commands to LR. Included is a set of basic Midi2LR Profiles designed for the Schwurbler MVP control surface and Lightroom 10.

The .zip package also includes a PDF file which shows the mapping of the buttons for the Menu. The menu can always be accessed from the button on the bottom right hand side. The second PDF can function as a template to record your own custom profiles.



=============
Installation:
=============

1) Copy the .xml files from the Midi2LR-Profiles folder to your local profiles folder. All profiles must be in the same directory.


2) Load the "Schwurbler-MVP-v1-Config.txt" file in Lightroom under File ⇢ Plug-in Extras ⇢ MIDI2LR ⇢ Import




===========================
For more information visit:
===========================

Github
https://github.com/mommel/hs-lr-midi-schwurbler

HS-Slack
https://happyshooting.de/der-hs-slack/




